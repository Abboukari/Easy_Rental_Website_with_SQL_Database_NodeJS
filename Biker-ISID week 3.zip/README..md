Maak een map .gitignore aan en zet daar de volgende bestanden en files in
node_modules
.eslintrc.json
package-lock.json
package.json
prettierrc
.gitignore

in je Terminal:
node -v (om te checken of je node op je systeem hebt staan, zo niet installeer die dan eerst)

npm init (https://www.linkedin.com/learning/learning-npm-the-node-package-manager-3/initializing-a-package-json-file?u=2167265)

npm install express

npm install -eslint (optioneel)
npx eslint --init (ik heb de volgende opties gekozen
To check syntax and find problems, and enforce code style
CommonJS (require/exports
NOne of these
no
node
Use a popular style guide
AirBnB
json
yes
)

npm install -D prettier eslint-config-prettier eslint-plugin-prettier (optioneel maar zeer aan te raden) (pas hierna ook je package.json file aan en maar een file .prettierrc)

npm install -D nodemon
(hierna vervolgens ook weer je pakage.json file aanpassen)

npm install cookie-session
npm install ejs

Nu loopt alles als het goed is op rolletjes
